const express = require('express');
const port = process.env.PORT;
require('./config/dataBase')
//carregar bibliotecas globais
//const AuthController = require('./routes/auth.route.js');
const cors = require('./config/cors');
const bodyParser = require('body-parser');
const expressSanitizer = require('express-sanitizer');
const expressValidator = require('express-validator');
//iniciar a aplicação
var server = express();
server.use(bodyParser.json(), bodyParser.urlencoded({ extended: true }));
server.use(expressSanitizer());
server.use(expressValidator());

server.listen(port, () => { console.log('Server UP ;) on port' + port) })

//forçar utilização das bibliotecas
server.use(cors)



module.exports = server

require('./routes/user.route.js');
require('./routes/classroom.route.js');
require('./routes/logs.route.js');
require('./routes/schedules.route.js');
require('./routes/auth.route.js');