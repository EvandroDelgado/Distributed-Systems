const server = require('../server');
var VerifyToken = require('../config/VerifyToken');

const controllerUser = require('../controller/user.controller');

server.get('/users/', controllerUser.read);
server.get('/users/:id', controllerUser.readID);
server.put('/auth/users/',VerifyToken, controllerUser.update);
