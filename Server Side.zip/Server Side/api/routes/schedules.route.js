const server = require('../server');
var VerifyToken = require('../config/VerifyToken');

const controllerSchedules = require('../controller/schedules.controller');

server.get('/schedules/', controllerSchedules.read);
server.post('/schedules/', VerifyToken, controllerSchedules.save);
