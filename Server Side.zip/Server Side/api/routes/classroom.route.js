const server = require('../server');
var VerifyToken = require('../config/VerifyToken');
const controllerClassroom = require('../controller/classroom.controller');

server.get('/classrooms/', controllerClassroom.read);
server.get('/classrooms/:id', controllerClassroom.readID);
server.put('/classrooms/:id', controllerClassroom.update)
//server.put('/classrooms/:id',VerifyToken, controllerClassroom.update)
