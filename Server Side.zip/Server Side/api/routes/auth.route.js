const server = require('../server');

const controllerAuth = require('../config/AuthController');

server.post('/auth/register/', controllerAuth.signUp);
server.get('/auth/logout/', controllerAuth.signOut );
server.post('/auth/login/', controllerAuth.signIn );