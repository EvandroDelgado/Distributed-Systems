const server = require('../server');
var VerifyToken = require('../config/VerifyToken');

const controllerLogs = require('../controller/logs.controller');

server.get('/logs/', controllerLogs.read);
server.post('/logs/',VerifyToken, controllerLogs.save);
