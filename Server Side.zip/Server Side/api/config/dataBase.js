const mongoose= require("mongoose")
mongoose.Promise = global.Promise
mongoose.connect('mongodb://eb2Admins:jejms2018@ds121289.mlab.com:21289/esmadrooms', { useNewUrlParser: true });