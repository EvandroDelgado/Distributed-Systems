// AuthController.js
var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
router.use(bodyParser.urlencoded({ extended: false }));
router.use(bodyParser.json());
var User = require('../model/user.model');

var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var config = require('./config');
var VerifyToken = require('./VerifyToken');
const saltRounds  = bcrypt.genSaltSync()

const signUp = (req, res) => {
    
    //receber os dados do formuário que são enviados por post
    const name = req.sanitize('name').escape();
    const email = req.sanitize('email').escape();
    const password = req.sanitize('password').escape();
    const admin = false;
    var hashedPassword = bcrypt.hashSync(req.body.password, 8);

    User.create({
        name: name,
        email: email,
        password: hashedPassword,
        admin: admin
    },
        function (err, user) {
            if (err) return res.status(500).send("There was a problem registering the user.")
            // create a token
            var token = jwt.sign({ id: user._id }, config.secret, {
                expiresIn: 86400 // expires in 24 hours
            });
            res.status(200).send({ auth: true, token: token });
        });
}

const signIn = (req, res) => {
    
    User.findOne({ email: req.body.email }, function (err, user) {
        if (err) return res.status(500).send('Error on the server.');
        if (!user) return res.status(404).send('No user found.');
        var passwordIsValid = bcrypt.compareSync(req.body.password, user.password);
        if (!passwordIsValid) return res.status(401).send({ auth: false, token: null });
        var token = jwt.sign({ id: user._id }, config.secret, {
            expiresIn: 86400 // expires in 24 hours
        });
        console.log("Login efetuado")
        res.status(200).send({ auth: true, token: token, id: user._id, admin: user.admin});
    });
}

const signOut = (req, res) => {
    //Set-Cookie: token=deleted; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT
    res.status(200).send({ auth: false, token: null });
}

//module.exports = router;
module.exports = {
    signUp: signUp,
    signOut: signOut,
    signIn: signIn
};