// config.js
module.exports = {
  'secret': 'supersecret'
};