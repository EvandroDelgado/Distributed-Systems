require('../model/user.model')
const mongoose = require('mongoose')
const TaskUsers = mongoose.model('users')

//definição de constantes
const bcrypt = require('bcrypt');
const saltRounds  = bcrypt.genSaltSync()

//função de leitura que retorna o resultado no callback
const read = (req, res) => {
    //criar e executar a query de leitura na BD
    TaskUsers.find((err, rows) => {
        if (!err) {
            //verifica os resultados se o número de linhas for 0 devolve dados não encontrados, caso contrário envia os resultados(rows).
            if (rows.length == 0) {
                res.status(404).send("Data not found");
            } else {
                res.status(200).send(rows);
            }
        } else
            console.log('Error while performing Query.', err);
    });
}

//função de leitura que retorna o resultado de um iduser
const readID = (req, res) => {
    //criar e executar a query de leitura na BD
    const idUser = req.sanitize('id').escape();
    const post = {
        _id: idUser
    };
    TaskUsers.findOne({ _id: post},{ password: 0 }, (err, rows) => {
        if (!err) {
            //verifica os resultados se o número de linhas for 0 devolve dados não encontrados, caso contrário envia os resultados(rows).
            if (rows.length == 0) {
                res.status(404).send({
                    "msg": "data not found"
                });
            } else {
                res.status(200).send(rows);
            }
        } else
        {
            res.status(400).send({ "msg": err.code });
            console.log('Error while performing Query.', err);
        }
    });
}

//função que atualiza a password de um utilizador
const update = (req, res,next) => {
      var token = req.body.token;
    //receber os dados do formuário que são enviados por post
    const password = req.sanitize('password').escape();
    
    //console.log("without hash:" + password);
    
    const hash = bcrypt.hashSync(password, saltRounds)
    //console.log("with hash:" + hash);
    
    req.body.update_at = new Date()
    //console.log(req.userId)
    
    TaskUsers.findOneAndUpdate({_id: req.userId}, {$set: { password: hash }}, (err, rows) => {
        if (!err) {
            res.status(200).send({ "msg": "update with success" });
        } else {
            res.status(400).send({ "msg": err.code });
            console.log('Error while performing Query.', err);
        }
    });
    console.log("token: " + token);
}

module.exports = {
    read: read,
    readID: readID,
    update: update
};