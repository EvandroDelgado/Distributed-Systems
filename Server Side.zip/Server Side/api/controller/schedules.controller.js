require('../model/schedules.model')
const mongoose = require('mongoose')
const TaskSchedules = mongoose.model('schedules')

//função de leitura que retorna o resultado no callback
const read = (req, res) => {
    //criar e executar a query de leitura na BD
    TaskSchedules.find((err, rows) => {
        if (!err) {
            //verifica os resultados se o número de linhas for 0 devolve dados não encontrados, caso contrário envia os resultados(rows).
            if (rows.length == 0) {
                res.status(404).send("Data not found");
            } else {
                res.status(200).send(rows);
            }
        } else
            console.log('Error while performing Query.', err);
    });
}

//função de gravação que recebe os 6 parâmetros
const save = (req, res) => {

    //receber os dados do formuário que são enviados por post
    const id_users = req.sanitize('id_users').escape();
    const id_classrooms = req.sanitize('id_classrooms').escape();
    const subject = req.sanitize('subject').escape();
    const day_week = req.sanitize('day_week').escape();
    const hour_in = req.sanitize('hour_in').escape();
    const hour_out = req.sanitize('hour_out').escape();

        var post = {
            id_users: id_users,
            id_classrooms: id_classrooms,
            subject: subject,
            day_week: day_week,
            hour_in: hour_in,
            hour_out: hour_out
        };

        const createSchedules = new TaskSchedules(post)
        createSchedules.save((err, task) => {
            if (!err) {
                res.status(200).location(task.insertId).send({
                    "msg": "inserted with success"
                });
            } else {
                if (err.code == "ER_DUP_ENTRY") {
                    res.status(409).send({ "msg": err.code });
                    console.log('Error while performing Query.', err);
                } else res.status(400).send({ "msg": err.code });
            }
        });
}

module.exports = {
    read: read,
    save: save
};