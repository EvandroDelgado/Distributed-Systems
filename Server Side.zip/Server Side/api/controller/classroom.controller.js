require('../model/classroom.model')
const mongoose = require('mongoose')
const TaskClassrooms = mongoose.model('classrooms')

//função de leitura que retorna o resultado no callback
const read = (req, res) => {
    //criar e executar a query de leitura na BD
    TaskClassrooms.find((err, task) => {
        if (!err) {
            //verifica os resultados se o número de linhas for 0 devoslve dados não encontrados, caso contrário envia os resultados(task).
            if (task.length == 0) {
                res.status(404).send("Data not found");
            } else {
                res.status(200).send(task);
            }
        } else
            console.log('Error while performing Query.', err);
    });
}

//função de leitura que retorna o resultado de uma sala
const readID = (req, res) => {
    //criar e executar a query de leitura na BD
    const idRoom = req.sanitize('id').escape();
    const post = {
        _id: idRoom
    };
    TaskClassrooms.findOne({ _id: post }, (err, task) => {
        if (!err) {
            //verifica os resultados se o número de linhas for 0 devolve dados não encontrados, caso contrário envia os resultados(task).
            if (task.length == 0) {
                res.status(404).send({
                    "msg": "data not found"
                });
            } else {
                res.status(200).send(task);
            }
        } else
        {
            res.status(400).send({"msg": err.code});
            console.log('Error while performing Query.', err);
        }
        
    });
}

//efetuar updade da variavel 'active' de uma determinada sala
const update = (req, res) => {

    //receber os dados do formuário que são enviados por post
    const idRoom = req.sanitize('id').escape();
    const _active = req.sanitize('active').escape();
    console.log(req.body.active)
    
    console.log("with sanitize:" + _active);
    
    req.body.update_at = new Date()
    
    TaskClassrooms.findOneAndUpdate({ _id: idRoom }, {$set: { active: _active }}, { new: true }, (err, rows) => {
        if (!err) {
            res.status(200).send({ "msg": "update with success" });
        } else {
            res.status(400).send({ "msg": err.code });
            console.log('Error while performing Query.', err);
        }
    });
}




module.exports = {
    read: read,
    readID: readID,
    update: update
};