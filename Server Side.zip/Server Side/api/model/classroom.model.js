const mongoose = require('mongoose')
const Schema = mongoose.Schema

var Classroom = new Schema({
    doorNumber: {
        type: Number,
        required: true,
    },
    active: {
        type: Boolean,
        required: true
    },
    created_at: {type: Date, default: Date.now},
    update_at: {type: Date, default: Date.now}
});

module.exports = mongoose.model('classrooms', Classroom);