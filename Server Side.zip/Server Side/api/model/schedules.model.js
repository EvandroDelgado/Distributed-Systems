const mongoose = require('mongoose')
const Schema = mongoose.Schema

var Schedules = new Schema({
    id_users: {
        type: String,
        required: true,
    },
    id_classrooms: {
        type: String,
        required: true
    },
    subject: {
        type: String,
        required: true
    },
    day_week: {
        type: String,
        required: true
    },
    hour_in: {
        type: Date,
        required: true
    },
    hour_out: {
        type: Date,
        required: true
    },
    created_at: {type: Date, default: Date.now},
    update_at: {type: Date, default: Date.now}
});

module.exports = mongoose.model('schedules', Schedules);