const mongoose = require('mongoose')
const Schema = mongoose.Schema

var Logs = new Schema({
    id_users: {
        type: String,
        required: true,
    },
    id_classrooms: {
        type: String,
        required: true
    },
    date: {
        type: Date,
        required: true
    },
    active: {
        type: Boolean,
        required: true
    },
    created_at: {type: Date, default: Date.now},
    update_at: {type: Date, default: Date.now}
});

module.exports = mongoose.model('logs', Logs);